
import os
import json
import uuid
import decimal
import boto3
from boto3.dynamodb.conditions import Key, Attr

DYNAMO_TABLE = os.environ.get("TABLE_NAME", "Items")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(DYNAMO_TABLE)

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return super().default(o)

def respond(code, body):
    return {
        "statusCode": code,
        "headers": {"Content-Type":"application/json"},
        "body": json.dumps(body, cls=DecimalEncoder)
    }

def lambda_handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method") or event.get("httpMethod")
    path = event.get("rawPath") or event.get("path","")
    params = event.get("pathParameters") or {}
    if method=="POST" and path.endswith("/items"):
        return create_item(event)
    if method=="GET" and path.endswith("/items") and not params.get("id"):
        return list_items()
    if method=="GET" and params.get("id"):
        return get_item(params["id"])
    if method=="PUT" and params.get("id"):
        return update_item(event, params["id"])
    if method=="DELETE" and params.get("id"):
        return delete_item(params["id"])
    return respond(404, {"message":"Not Found"})

def get_body(event):
    b=event.get("body")
    if isinstance(b,str):
        try: return json.loads(b)
        except: return None
    return b

def create_item(event):
    body=get_body(event)
    if not body: return respond(400,{"message":"Invalid body"})
    item_id=str(uuid.uuid4())
    item={"id":item_id, "name":body.get("name",""), "description":body.get("description","")}
    table.put_item(Item=item)
    return respond(201,item)

def get_item(item_id):
    res=table.get_item(Key={"id":item_id})
    if "Item" not in res: return respond(404,{"message":"Not found"})
    return respond(200,res["Item"])

def list_items():
    res=table.scan()
    return respond(200,{"items":res.get("Items",[])})

def update_item(event,item_id):
    body=get_body(event)
    if not body: return respond(400,{"message":"Invalid body"})
    expr="SET "
    names={}
    vals={}
    updates=[]
    if "name" in body:
        updates.append("#n=:name")
        names["#n"]="name"
        vals[":name"]=body["name"]
    if "description" in body:
        updates.append("description=:d")
        vals[":d"]=body["description"]
    if not updates: return respond(400,{"message":"Nothing to update"})
    expr+= ", ".join(updates)
    res=table.update_item(Key={"id":item_id},UpdateExpression=expr,
                          ExpressionAttributeNames=names if names else None,
                          ExpressionAttributeValues=vals,ReturnValues="ALL_NEW")
    return respond(200,res["Attributes"])

def delete_item(item_id):
    res=table.delete_item(Key={"id":item_id},ReturnValues="ALL_OLD")
    if "Attributes" not in res: return respond(404,{"message":"Not found"})
    return respond(200,{"message":"Deleted","item":res["Attributes"]})
