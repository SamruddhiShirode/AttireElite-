# AWS Serverless CRUD App
Deploy using SAM.
